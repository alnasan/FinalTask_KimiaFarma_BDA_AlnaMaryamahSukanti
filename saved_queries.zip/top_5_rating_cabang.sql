-- 7. Top 5 Cabang dengan Rating Tertinggi, Namun Rating Transaksi Terendah (Data Statis)
CREATE OR REPLACE TABLE kimia_farma.top_5_rating_cabang
AS
SELECT 
    kc.branch_id,
    kc.branch_name,
    kc.provinsi,
    kc.rating AS rating_cabang,
    AVG(ft.rating) AS rating_transaksi
FROM `kimia_farma.kf_final_transaction` ft
JOIN `kimia_farma.kf_kantorcabang` kc
ON ft.branch_id = kc.branch_id
GROUP BY kc.branch_id, kc.branch_name, kc.provinsi, kc.rating
ORDER BY kc.rating DESC, rating_transaksi ASC
LIMIT 5;

CREATE OR REPLACE VIEW kimia_farma.vw_top_5_rating_cabang AS
SELECT * FROM kimia_farma.top_5_rating_cabang;