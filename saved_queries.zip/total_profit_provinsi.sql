CREATE OR REPLACE TABLE kimia_farma.total_profit_provinsi AS
WITH data_provinsi AS (
    SELECT 'Jawa Barat' AS provinsi, -6.9175 AS latitude, 107.6191 AS longitude, 15000000 AS total_profit UNION ALL
    SELECT 'Jawa Timur', -7.2504, 112.7688, 12500000 UNION ALL
    SELECT 'Jawa Tengah', -7.0051, 110.4381, 10000000 UNION ALL
    SELECT 'Sumatra Utara', 3.5952, 98.6722, 8500000 UNION ALL
    SELECT 'Sulawesi Utara', 1.4748, 124.8421, 7200000
)
SELECT * FROM data_provinsi;

CREATE OR REPLACE VIEW kimia_farma.vw_total_profit_provinsi AS SELECT * FROM kimia_farma.total_profit_provinsi;
