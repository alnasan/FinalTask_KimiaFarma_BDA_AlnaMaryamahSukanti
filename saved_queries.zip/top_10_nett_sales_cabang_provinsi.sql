-- 8. top_10_nett_sales_cabang_provinsi
CREATE OR REPLACE TABLE kimia_farma.top_10_nett_sales_cabang_provinsi AS
SELECT 
    kc.provinsi, 
    kc.branch_name, 
    SUM(ft.price * (1 - ft.discount_percentage / 100)) AS nett_sales
FROM `kimia_farma.kf_final_transaction` ft
JOIN `kimia_farma.kf_kantorcabang` kc 
ON ft.branch_id = kc.branch_id
GROUP BY 1, 2
ORDER BY nett_sales DESC
LIMIT 10;

CREATE OR REPLACE VIEW kimia_farma.vw_top_10_nett_sales_cabang_provinsi AS
SELECT * FROM kimia_farma.top_10_nett_sales_cabang_provinsi;