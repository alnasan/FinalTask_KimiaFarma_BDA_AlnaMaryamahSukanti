CREATE OR REPLACE TABLE kimia_farma.geo_map_total_profit_per_provinsi AS
SELECT 
    kc.provinsi,
    SUM(ft.price * (1 - ft.discount_percentage / 100) * 
        CASE 
            WHEN ft.price <= 50000 THEN 0.1
            WHEN ft.price > 50000 AND ft.price <= 100000 THEN 0.15
            WHEN ft.price > 100000 AND ft.price <= 300000 THEN 0.2
            WHEN ft.price > 300000 AND ft.price <= 500000 THEN 0.25
            ELSE 0.3
        END
    ) AS total_profit
FROM `kimia_farma.kf_final_transaction` ft
JOIN `kimia_farma.kf_kantorcabang` kc 
ON ft.branch_id = kc.branch_id
GROUP BY 1;

CREATE OR REPLACE VIEW kimia_farma.vw_geo_map_total_profit_per_provinsi AS
SELECT * FROM kimia_farma.geo_map_total_profit_per_provinsi;
