-- 3. Cabang dengan Penjualan Terbaik
CREATE OR REPLACE TABLE kimia_farma.cabang_terbaik AS
SELECT 
    c.branch_id,
    c.branch_name,
    c.kota,
    c.provinsi,
    COUNT(t.transaction_id) AS total_transaksi,
    SUM(t.price * (1 - t.discount_percentage / 100)) AS total_pendapatan
FROM kimia_farma.kf_final_transaction t
JOIN kimia_farma.kf_kantorcabang c ON t.branch_id = c.branch_id
GROUP BY c.branch_id, c.branch_name, c.kota, c.provinsi
ORDER BY total_pendapatan DESC;

CREATE OR REPLACE VIEW kimia_farma.vw_cabang_terbaik AS
SELECT * FROM kimia_farma.cabang_terbaik;