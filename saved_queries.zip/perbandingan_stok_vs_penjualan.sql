-- 4. Perbandingan Stok vs Penjualan
CREATE OR REPLACE TABLE kimia_farma.perbandingan_stok_vs_penjualan AS
SELECT 
    i.branch_id,
    i.product_id,
    i.product_name,
    i.opname_stock AS stok_awal,
    COUNT(t.transaction_id) AS total_terjual
FROM kimia_farma.kf_inventory i
LEFT JOIN kimia_farma.kf_final_transaction t 
    ON i.branch_id = t.branch_id AND i.product_id = t.product_id
GROUP BY i.branch_id, i.product_id, i.product_name, i.opname_stock
ORDER BY total_terjual DESC;

CREATE OR REPLACE VIEW kimia_farma.vw_perbandingan_stok_vs_penjualan AS
SELECT * FROM kimia_farma.perbandingan_stok_vs_penjualan;