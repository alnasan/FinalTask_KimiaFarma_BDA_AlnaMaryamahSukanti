CREATE OR REPLACE TABLE kimia_farma.summary_dashboard AS
SELECT 
    COUNT(DISTINCT ft.transaction_id) AS total_transaksi,
    SUM(ft.price * (1 - ft.discount_percentage / 100)) AS total_pendapatan,
    AVG(ft.discount_percentage) AS rata_rata_diskon,
    AVG(ft.rating) AS rata_rata_rating
FROM `kimia_farma.kf_final_transaction` ft;

CREATE OR REPLACE VIEW kimia_farma.vw_summary_dashboard AS
SELECT * FROM kimia_farma.summary_dashboard;