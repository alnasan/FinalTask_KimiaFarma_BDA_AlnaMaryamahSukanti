-- 2. Produk Terlaris
CREATE OR REPLACE TABLE kimia_farma.produk_terlaris AS
SELECT 
    p.product_id,
    p.product_name,
    COUNT(t.transaction_id) AS jumlah_terjual,
    SUM(t.price * (1 - t.discount_percentage / 100)) AS total_pendapatan
FROM kimia_farma.kf_final_transaction t
JOIN kimia_farma.kf_product p ON t.product_id = p.product_id
GROUP BY p.product_id, p.product_name
ORDER BY jumlah_terjual DESC
LIMIT 10;

CREATE OR REPLACE VIEW kimia_farma.vw_produk_terlaris AS
SELECT * FROM kimia_farma.produk_terlaris;