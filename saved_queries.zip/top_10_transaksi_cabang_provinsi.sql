-- 6. top 10 transaksi cabang provinsi
CREATE OR REPLACE TABLE kimia_farma.top_10_transaksi_cabang_provinsi AS
SELECT 
    kc.provinsi, 
    kc.branch_name, 
    COUNT(ft.transaction_id) AS total_transaksi
FROM `kimia_farma.kf_final_transaction` ft
JOIN `kimia_farma.kf_kantorcabang` kc 
ON ft.branch_id = kc.branch_id
GROUP BY 1, 2
ORDER BY total_transaksi DESC
LIMIT 10;

CREATE OR REPLACE VIEW kimia_farma.vw_top_10_transaksi_cabang_provinsi AS
SELECT * FROM kimia_farma_analysis.top_10_transaksi_cabang_provinsi;
